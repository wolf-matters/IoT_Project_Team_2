# -*- coding: utf-8 -*-
"""
Created on Sun Dec 26 12:52:33 2021

@author: marne
"""

import paho.mqtt.client as mqtt #import the client1
import time
import math

# Import the pySerial library.
# documentation: https://pyserial.readthedocs.io/en/latest/
import serial
import struct
import json


# MQTT publication topic.  This is usually the students Andrew ID.
mqtt_topic = 'losant/61a6488ab66dd04d25b858b3/state'

# Serial port device to bridge to the network (e.g. Arduino).
# On Windows, this will usually be similar to 'COM5'.
# On macOS, this will usually be similar to '/dev/cu.usbmodem333101'
serial_portname = '/dev/ttyUSB0'
#serial_portname = 'COM14'
broker_address="127.0.0.1"
#broker_address="192.168.1.100"





############
def on_message(client, userdata, message):
    print("message received " ,str(message.payload.decode("utf-8")))
    print("message topic=",message.topic)
    print("message qos=",message.qos)
    print("message retain flag=",message.retain)


def ascii_to_int(c):
    v = len(c)
    c = bytes(c,'ascii')
    c = struct.unpack('B'*len(c),c)
    sn = 0
    for idx,j in enumerate(c):
        sn = (j - 48) * 10**(len(c)-(1+idx)) + sn
    return sn


########################################


print("creating new instance")
client = mqtt.Client("P1") #create new instance
client.on_message=on_message #attach function to callback
print("connecting to broker")
client.connect(broker_address) #connect to broker
client.loop_start() #start the loop
print("Subscribing to topic",mqtt_topic)
client.subscribe(mqtt_topic)

time.sleep(4) # wait

# Connect to the serial device.
serialPort = serial.Serial(serial_portname, baudrate=115200)

try:
    
    # wait briefly for the Arduino to complete waking up
    time.sleep(0.2)
    serialPort.write(b'rf rx_con on')
    serialString = serialPort.readline()



    while(1):

        # Wait until there is data waiting in the serial buffer
        if(serialPort.in_waiting > 0):

            # Read data out of the buffer until a carraige return / new line is found
            serialString = serialPort.readline()

            # Print the contents of the serial data
            asciiString = serialString.decode('Ascii')
            print(asciiString)
            listString = asciiString.split(" ")
            print(listString)
            if(len(listString) > 1):
                if(listString[1] == "radio_rx"):
                    
                    print('decoding control code...',)
                    try:
                        packet = bytes.fromhex(listString[2])
                        ascii_packet = packet.decode("ASCII")
                        control_code = int(ascii_packet[0:8])
                        print('control code:',control_code)
                    
                        if ascii_packet[0:8] == '00000001': #control code
                    
                            #accel_reading = ascii_packet[8:16].strip()
                            accel_reading = math.sqrt(float(ascii_packet[8:16]))
                            print('decoding... accelerometer gforce is', accel_reading)
                            if client.is_connected():
                                #mqtt_to_send = {accel_reading}
                                #mqtt_to_send = json.dumps(mqtt_to_send)
                                client.publish(topic=mqtt_topic,
                                               payload=json.dumps({"data":
                                                               {"acceleration":
                                                                accel_reading}}))
                                
                                
                                
                        elif ascii_packet[0:8] == '00000002': #control code
                            temp_reading = float(ascii_packet[8:16]) 
                            #temp_reading = ascii_packet[8:16].strip()
                            humidity_reading = float(ascii_packet[16:24])
                    
                            print('decoding... temp/humdity  is',temp_reading,humidity_reading)
                            if client.is_connected():
                                #mqtt_to_send = {accel_reading}
                                #mqtt_to_send = json.dumps(mqtt_to_send)
                                client.publish(topic=mqtt_topic,
                                           payload=json.dumps({"data":
                                                               {"temperature":
                                                                temp_reading}}))
                                
                                client.publish(topic=mqtt_topic,
                                           payload=json.dumps({"data":
                                                               {"humidity":
                                                                humidity_reading}}))
                                                                
                        elif ascii_packet[0:8] == '00000003': #control code
                            second_code = int(ascii_packet[8:16])
                            print(second_code) 
                            if second_code == 1:
                                third_code = int(ascii_packet[16:24])
                                print(third_code)
                                if third_code == 1:
                                    print('decoding... user is paniced!')
                                    if client.is_connected():
                                        client.publish(topic=mqtt_topic,
                                           payload=json.dumps({"data":
                                                               {"ID_001_PANIC_STATUS":
                                                                True}}))
                                if third_code == 2:
                                    print('decoding... user is not paniced')
                                    if client.is_connected():
                                        client.publish(topic=mqtt_topic,
                                           payload=json.dumps({"data":
                                                               {"ID_001_PANIC_STATUS":
                                                                False}}))
                                
                            
                    except UnicodeDecodeError:
                        print("Unknown-packet-format-detected")
                        pass
    
finally:
    serialPort.close()
    client.loop_stop() #stop the loop


